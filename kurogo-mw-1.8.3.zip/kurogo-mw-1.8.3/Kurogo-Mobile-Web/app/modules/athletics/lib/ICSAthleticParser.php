<?php

includePackage('Calendar');
class ICSAthleticParser extends ICSDataParser
{
    protected $calendarClass='AthleticCalendar';
}

